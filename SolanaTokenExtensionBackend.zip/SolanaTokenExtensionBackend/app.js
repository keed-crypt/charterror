const express = require('express');
const cors = require('cors');
const axios = require('axios');
const { fetchTokenInfo } = require('./token-fetch'); // Token fetcher from Helius
const { queryLpByToken, calculateBurnPercentage } = require('./burn-percentage'); // Liquidity and burn calculation
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const HELIUS_API_KEY = process.env.HELIUS_API_KEY || 'bc250aa3-bfd6-4854-a435-e3c41c46c6c1'; // Helius API Key

// API to fetch token information
app.post('/api/getTokenInfo', async (req, res) => {
  const { contractAddress } = req.body;

  if (!contractAddress) {
    return res.status(400).json({ error: 'Contract address is required' });
  }

  const tokenInfo = await fetchTokenInfo(HELIUS_API_KEY, contractAddress);

  if (!tokenInfo) {
    return res.status(500).json({ error: 'Failed to fetch token information' });
  }

  res.json(tokenInfo);
});

// API to calculate burn percentage based on token mint address
app.post('/api/getBurnPercentage', async (req, res) => {
  const { tokenMint } = req.body;

  if (!tokenMint) {
    return res.status(400).json({ error: 'Token mint address is required' });
  }

  try {
    const burnPercentage = await calculateBurnPercentage(tokenMint);

    if (!burnPercentage) {
      return res.status(500).json({ error: 'Failed to calculate burn percentage' });
    }

    res.json({ burnPercentage });
  } catch (error) {
    console.error("Error calculating burn percentage:", error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// New API to get token info, burn percentage, mint/freeze authority, and Dex Screener chart data
app.post('/api/getFullTokenDetails', async (req, res) => {
  const { contractAddress, tokenMint } = req.body;

  if (!contractAddress || !tokenMint) {
    return res.status(400).json({ error: 'Contract address and token mint are required' });
  }

  try {
    // Fetch token information
    const tokenInfo = await fetchTokenInfo(HELIUS_API_KEY, contractAddress);

    if (!tokenInfo) {
      return res.status(500).json({ error: 'Failed to fetch token information' });
    }

    // Fetch burn percentage
    const burnPercentage = await calculateBurnPercentage(tokenMint);
    if (burnPercentage === null) {
      return res.status(500).json({ error: 'Failed to calculate burn percentage' });
    }

    // Fetch Dex Screener chart data
    const dexScreenerUrl = `https://api.dexscreener.com/latest/dex/tokens/${tokenMint}`;
    const chartResponse = await axios.get(dexScreenerUrl);
    const chartData = chartResponse.data;

    // Extract mint and freeze authority, and token icon
    const mintAuthority = tokenInfo.content?.metadata?.mintAuthority ? "Enabled" : "Disabled";
    const freezeAuthority = tokenInfo.content?.metadata?.freezeAuthority ? "Enabled" : "Disabled";
    const tokenIcon = tokenInfo.content?.files?.[0]?.uri || "Icon not available";

    // Simplify the response and include chart data
    const simplifiedResponse = {
      name: tokenInfo.content?.metadata?.name || "N/A",
      symbol: tokenInfo.content?.metadata?.symbol || "N/A",
      description: tokenInfo.content?.metadata?.description || "No description available",
      price_per_token: tokenInfo.token_info?.price_info?.price_per_token || "Price info not available",
      total_supply: tokenInfo.token_info?.supply
        ? (tokenInfo.token_info.supply / Math.pow(10, tokenInfo.token_info.decimals)).toFixed(5)
        : "Supply info not available",
      currency: tokenInfo.token_info?.price_info?.currency || "Unknown",
      burn_percentage: burnPercentage ? `${burnPercentage}% LP burned` : "Burn percentage not available",
      mint_authority: mintAuthority,
      freeze_authority: freezeAuthority,
      token_icon: tokenIcon,
      chart_data: chartData
    };

    res.json(simplifiedResponse);

  } catch (error) {
    console.error('Error fetching token details or burn percentage:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// New API to fetch token transfer data for Dot2Dot visualization
app.get('/api/getTokenTransfers', async (req, res) => {
  const contractAddress = req.query.contractAddress;

  try {
    const heliusUrl = `https://api.helius.xyz/v0/addresses/${contractAddress}/transactions?api-key=${HELIUS_API_KEY}`;
    const response = await axios.get(heliusUrl);

    // Process the data to get wallet interactions
    const transfers = response.data.map(tx => ({
      source: tx.sender,
      target: tx.receiver,
      amount: tx.amount // Adjust based on actual API response format
    }));

    // Create nodes and links for Dot2Dot visualization
    const nodes = {};
    transfers.forEach(transfer => {
      if (!nodes[transfer.source]) nodes[transfer.source] = { id: transfer.source, balance: 0 };
      if (!nodes[transfer.target]) nodes[transfer.target] = { id: transfer.target, balance: 0 };
      nodes[transfer.source].balance += transfer.amount;
      nodes[transfer.target].balance += transfer.amount;
    });

    const nodeArray = Object.values(nodes);
    const linkArray = transfers.map(transfer => ({
      source: transfer.source,
      target: transfer.target,
      value: transfer.amount
    }));

    // Send nodes and links to the client for D3 visualization
    res.json({ nodes: nodeArray, links: linkArray });

  } catch (error) {
    console.error('Error fetching token transfers:', error);
    res.status(500).send('Failed to fetch token transfers');
  }
});

// Server listening
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
